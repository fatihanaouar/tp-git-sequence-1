#include <iostream>
int main()
{
std::cout << "Bienvenue le monde !" << std::endl;
return 0;
}
